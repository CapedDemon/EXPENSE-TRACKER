import expensetrackerclass

usersTracker = expensetrackerclass.ExpenseTracker()
usersTracker.loadFunc()
usersTracker.takeCommand()